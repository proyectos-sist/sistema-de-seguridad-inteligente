package modelo;

public class EstadoEntrada {
    private int identrada;
    private int estadoentrada;
    private int usuario_id;
    private int entrada_id;

    public EstadoEntrada() {
        this.identrada = 0;
        this.estadoentrada = 0;
        this.usuario_id = 0;
        this.entrada_id = 0;
    }

    public EstadoEntrada(int identrada, int estadoentrada, int usuario_id, int entrada_id) {
        this.identrada = identrada;
        this.estadoentrada = estadoentrada;
        this.usuario_id = usuario_id;
        this.entrada_id = entrada_id;
    }

    public int getIdentrada() {
        return identrada;
    }

    public void setIdentrada(int identrada) {
        this.identrada = identrada;
    }

    public int getEstadoentrada() {
        return estadoentrada;
    }

    public void setEstadoentrada(int estadoentrada) {
        this.estadoentrada = estadoentrada;
    }

    public int getUsuario_id() {
        return usuario_id;
    }

    public void setUsuario_id(int usuario_id) {
        this.usuario_id = usuario_id;
    }

    public int getEntrada_id() {
        return entrada_id;
    }

    public void setEntrada_id(int entrada_id) {
        this.entrada_id = entrada_id;
    }

    @Override
    public String toString() {
        return "EstadoEntrada{" + "identrada=" + identrada + ", estadoentrada=" + estadoentrada + ", usuario_id=" + usuario_id + ", entrada_id=" + entrada_id + '}';
    }
    
}
