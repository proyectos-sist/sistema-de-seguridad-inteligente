package modelo;

import java.time.LocalDate;
import java.time.LocalTime;

public class Entrada {
    private int identrada;
    private LocalDate fecha;
    private LocalTime hora;
    private int usuario_id;

    public Entrada() {
        this.identrada = 0;
        this.fecha = LocalDate.parse("0000-01-01");
        this.hora = LocalTime.parse("00:00");
        this.usuario_id = 0;
    }

    public Entrada(int identrada, String fecha, String hora, int usuario_id) {
        this.identrada = identrada;
        this.fecha = LocalDate.parse(fecha);
        this.hora = LocalTime.parse(hora);
        this.usuario_id = usuario_id;
    }

    public int getIdentrada() {
        return identrada;
    }

    public void setIdentrada(int identrada) {
        this.identrada = identrada;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public LocalTime getHora() {
        return hora;
    }

    public void setHora(LocalTime hora) {
        this.hora = hora;
    }

    public int getUsuario_id() {
        return usuario_id;
    }

    public void setUsuario_id(int usuario_id) {
        this.usuario_id = usuario_id;
    }

    @Override
    public String toString() {
        return "Entrada{" + "identrada=" + identrada + ", fecha=" + fecha + ", hora=" + hora + ", usuario_id=" + usuario_id + '}';
    }
    
}
