package modelo;

import java.util.List;
import java.util.Scanner;


public class DetectorLector {


    public static void main(String[] args) {
        AdminEntradaDB objAdminEntradaDB = new AdminEntradaDB();
        AdminEstadoEntradaDB objAdminEstadoEntradaDB = new AdminEstadoEntradaDB();
        AdminFotografíaDB objAdminFotografíaDB = new AdminFotografíaDB();
        AdminRolDB objAdminRolDB = new AdminRolDB();
        AdminUsuarioDB objAdminUsuarioDB = new AdminUsuarioDB();
        
        //----------------------Menú de administración-------------------------
        //Variables para la navegación entre menús
        int opcion=0; int opcionRol=0; int opcionUsuario=0; int opcionFoto=0; int opcionEntrada=0; int opcionEstado=0;
        //Variables para la asignación de datos en un menú
        int valor=0;
        String nombre="";
        //Variables para salir de los menús}
        boolean salir=false; boolean salirRol=false; boolean salirUsuario=false; boolean salirFoto = false; boolean salirEntrada= false;
        boolean salirEstado=false;
        //Lectores de opción
        Scanner leerValor = new Scanner(System.in);
        Scanner leerNombre = new Scanner (System.in);
        while (!salir){
            System.out.println("\nMenú principal\n");
            System.out.println("1. Administrar Roles");
            System.out.println("2. Administrar Usuarios");
            System.out.println("3. Administrar Fotografías");
            System.out.println("4. Administrar Entradas a la institución");
            System.out.println("5. Administrar Estado de entradas a la insticución");
            System.out.println("6. Salir");
            System.out.print("\nIngrese una opción:");
            opcion = leerValor.nextInt();
            switch (opcion){
                case 1:
                    while (!salirRol){
                    System.out.println("\nMenú de administración de roles\n");
                        System.out.println("1. Leer todos los roles");
                        System.out.println("2. Leer un rol");
                        System.out.println("3. Insertar un rol");
                        System.out.println("4. Modificar un rol");
                        System.out.println("5. Eliminar un rol");
                        System.out.println("6. Salir");
                        System.out.println("\nIngrese una opcion;");
                        opcionRol = leerValor.nextInt();
                        switch (opcionRol){
                            case 1:
                                List<Object> rowsQuery = objAdminRolDB.listarTodo();
                                System.out.println("Se obtiene la información de la tabla:");
                                System.out.println(rowsQuery);
                                break;
                            case 2:
                                Rol objRol1 = new Rol();
                                break;
                            case 3:
                                Rol objRol2 = new Rol();
                                break;
                            case 4:
                                Rol objRol3 = new Rol();
                                break;
                            case 5:
                                Rol objRol4 = new Rol();
                                break;
                            case 6:
                                salirRol =true;
                                System.out.println("Saliendo del menú...");
                                break;
                            default:
                                System.out.println("Opción no valida. ¡Ingrese otra!");
                        }    
                    }     
                    break;
                case 2:
                    while (!salirUsuario){
                    System.out.println("\nMenú de administración de usuarios\n");
                        System.out.println("1. Leer todos los usuarios");
                        System.out.println("2. Leer un usuario");
                        System.out.println("3. Insertar un usuario");
                        System.out.println("4. Modificar un usuario");
                        System.out.println("5. Eliminar un usuario");
                        System.out.println("6. Salir");
                        System.out.println("\nIngrese una opcion:");
                        opcionUsuario = leerValor.nextInt();
                        switch (opcionUsuario){
                            case 1:
                                List<Object> rowsQuery = objAdminUsuarioDB.listarTodo();
                                System.out.println("Se obtiene la información de la tabla:");
                                System.out.println(rowsQuery);
                                break;
                            case 2:
                                Usuario objUsuario2 = new Usuario();
                                System.out.println("Ingrese el documento del usuario a buscar:");
                                nombre=leerNombre.nextLine();
                                objUsuario2.setDocumento(nombre);
                                objUsuario2=(Usuario) objAdminUsuarioDB.listarUno(objUsuario2);
                                System.out.println("Se encuentra el usuario: "+objUsuario2);
                                break;
                            case 3:
                                Usuario objUsuario1 = new Usuario();
                                System.out.println("Ingrese el documento:");
                                nombre = leerNombre.nextLine();
                                objUsuario1.setDocumento(nombre);
                                System.out.println("Ingrese los nombres:");
                                nombre = leerNombre.nextLine();
                                objUsuario1.setNombres(nombre);
                                System.out.println("Ingrese los apellidos:");
                                nombre = leerNombre.nextLine();
                                objUsuario1.setApellidos(nombre);
                                System.out.println("Ingrese el correo institucional:");
                                nombre = leerNombre.nextLine();
                                objUsuario1.setCorreoinstitucional(nombre);
                                System.out.println("Ingrese la dirección:");
                                nombre = leerNombre.nextLine();
                                objUsuario1.setDireccion(nombre);
                                System.out.println("Ingrese el telefono:");
                                nombre = leerNombre.nextLine();
                                objUsuario1.setTelefono(nombre);
                                System.out.println("Ingrese una fotografía como identificación:");
                                nombre = leerNombre.nextLine();
                                objUsuario1.setFotousuario(nombre);
                                System.out.println("...Autoasignación del rol al usuario...");
                                valor = leerValor.nextInt();
                                objUsuario1.setRol_id(valor);
                                objAdminUsuarioDB.insertar(objUsuario1);
                                System.out.println("Se ha ingresado el usuario:"+objUsuario1);
                                break;
                            case 4:
                                Usuario objUsuario3 = new Usuario();
                                System.out.println("Ingresa el documento del usuario a modificar:");
                                nombre=leerNombre.nextLine();
                                objUsuario3.setDocumento(nombre);
                                objUsuario3=(Usuario) objAdminUsuarioDB.listarUno(objUsuario3);
                                System.out.println("Se ha localizado el usuario: "+objUsuario3);
                                //Ajuste de datos al usuario
                                System.out.println("Ingrese los nombres:");
                                nombre = leerNombre.nextLine();
                                objUsuario3.setNombres(nombre);
                                System.out.println("Ingrese los apellidos:");
                                nombre = leerNombre.nextLine();
                                objUsuario3.setApellidos(nombre);
                                System.out.println("Ingrese el correo institucional:");
                                nombre = leerNombre.nextLine();
                                objUsuario3.setCorreoinstitucional(nombre);
                                System.out.println("Ingrese la dirección:");
                                nombre = leerNombre.nextLine();
                                objUsuario3.setDireccion(nombre);
                                System.out.println("Ingrese el telefono:");
                                nombre = leerNombre.nextLine();
                                objUsuario3.setTelefono(nombre);
                                System.out.println("Ingrese una fotografía como identificación:");
                                nombre = leerNombre.nextLine();
                                objUsuario3.setFotousuario(nombre);
                                System.out.println("...Autoasignación del rol al usuario...");
                                valor = leerValor.nextInt();
                                objUsuario3.setRol_id(valor);
                                break;
                            case 5:
                                Usuario objUsuario4 = new Usuario();
                                System.out.println("Ingresa el documento del usuario a eliminar:");
                                nombre=leerNombre.nextLine();
                                objUsuario4.setDocumento(nombre);
                                objAdminUsuarioDB.eliminar(objUsuario4);
                                break;
                            case 6:
                                salirUsuario=true;
                                System.out.println("Saliiendo del menú...");
                                break;
                            default:
                                System.out.println("Opción no valida. ¡Ingrese otra!");
                                
                        }
                    }
                    break;
                case 3:
                    while (!salirFoto){
                    System.out.println("\nMenú de administración de fotografías\n");
                        System.out.println("1. Leer todas las fotografías");
                        System.out.println("2. Leer una fotografía");
                        System.out.println("3. Insertar una fotografía");
                        System.out.println("4. Modificar una fotografía");
                        System.out.println("5. Eliminar una fotografía");
                        System.out.println("6. Salir");
                        System.out.println("\nIngrese una opcion;");
                        opcionFoto = leerValor.nextInt();
                        switch (opcionFoto){
                            case 1:
                                break;
                            case 2:
                                break;
                            case 3:
                                break;
                            case 4:
                                break;
                            case 5:
                                break;
                            case 6:
                                salirFoto=true;
                                System.out.println("Saliendo del menú...");
                                break;
                            default:
                                System.out.println("Opción no valida. ¡Ingrese otra!");
                                
                        }
                    }
                    break;
                case 4:
                    while(!salirEntrada){
                    System.out.println("\nMenú de administración de entradas a la institución\n");
                        System.out.println("1. Leer todas las entradas");
                        System.out.println("2. Leer una entrada");
                        System.out.println("3. Insertar una entrada");
                        System.out.println("4. Modificar una entrada");
                        System.out.println("5. Eliminar una entrada");
                        System.out.println("6. Salir");
                        System.out.println("\nIngrese una opcion;");
                        opcionEntrada = leerValor.nextInt();
                        switch (opcionEntrada){
                            case 1:
                                break;
                            case 2:
                                break;
                            case 3:
                                break;
                            case 4:
                                break;
                            case 5:
                                break;
                            case 6:
                                salirEntrada=true;
                                System.out.println("Saliendo del menú...");
                                break;
                            default:
                                System.out.println("Opción no valida. ¡Ingrese otra!");
                        }  
                    }
                    break;
                case 5:
                    while (!salirEstado){
                    System.out.println("\nMenú de administración de estados de entrada\n");
                        System.out.println("1. Leer todos los estados de entradas");
                        System.out.println("2. Leer un estado de entrada");
                        System.out.println("3. Insertar un estado de entrada");
                        System.out.println("4. Modificar un estado de entrada");
                        System.out.println("5. Eliminar un estado de entrada");
                        System.out.println("6. Salir");
                        System.out.println("\nIngrese una opcion;");
                        opcionRol = leerValor.nextInt();
                        switch (opcionRol){
                            case 1:
                                break;
                            case 2:
                                break;
                            case 3:
                                break;
                            case 4:
                                break;
                            case 5:
                                break;
                            case 6:
                                salirEstado=true;
                                System.out.println("Saliendo del menú...");
                                break;
                            default:
                                System.out.println("Opción no valida. ¡Ingrese otra!");
                                
                        }
                    }
                    break;
                case 6: // Salir del programa
                    salir=true;
                    System.out.println("¡Gracias por utilizar el programa!");
                default:
                    System.out.println("Opción no valida. ¡Ingrese otra!");
            }
        }
    }
    
}
