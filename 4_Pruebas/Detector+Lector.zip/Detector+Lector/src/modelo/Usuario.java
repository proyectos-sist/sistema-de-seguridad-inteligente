package modelo;

public class Usuario {
    private int idusuario;
    private String documento;
    private String nombres;
    private String apellidos;
    private String correoinstitucional;
    private String direccion;
    private String telefono;
    private String fotousuario;
    private int rol_id;

    public Usuario() {
        this.idusuario = 0;
        this.documento = "";
        this.nombres = "";
        this.apellidos = "";
        this.correoinstitucional = "";
        this.direccion = "";
        this.telefono = "";
        this.fotousuario = "";
        this.rol_id = 0;
    }

    public Usuario(int idusuario, String documento, String nombres, String apellidos, String correoinstitucional, String direccion, String telefono, String fotousuario, int rol_id) {
        this.idusuario = idusuario;
        this.documento = documento;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.correoinstitucional = correoinstitucional;
        this.direccion = direccion;
        this.telefono = telefono;
        this.fotousuario = fotousuario;
        this.rol_id = rol_id;
    }

    public int getIdusuario() {
        return idusuario;
    }

    public void setIdusuario(int idusuario) {
        this.idusuario = idusuario;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getCorreoinstitucional() {
        return correoinstitucional;
    }

    public void setCorreoinstitucional(String correinstitucional) {
        this.correoinstitucional = correinstitucional;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getFotousuario() {
        return fotousuario;
    }

    public void setFotousuario(String fotousuario) {
        this.fotousuario = fotousuario;
    }

    public int getRol_id() {
        return rol_id;
    }

    public void setRol_id(int rol_id) {
        this.rol_id = rol_id;
    }

    @Override
    public String toString() {
        return "Usuario{" + "idusuario=" + idusuario + ", documento=" + documento + ", nombres=" + nombres + ", apellidos=" + apellidos + ", correinstitucional=" + correoinstitucional + ", direccion=" + direccion + ", telefono=" + telefono + ", fotousuario=" + fotousuario + ", rol_id=" + rol_id + '}';
    }
    
}
