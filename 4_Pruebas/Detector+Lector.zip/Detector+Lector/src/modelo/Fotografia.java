package modelo;

public class Fotografia {
    private int idfoto;
    private String nombrefoto;
    private int usuario_id;

    public Fotografia() {
        this.idfoto = 0;
        this.nombrefoto = "";
        this.usuario_id = 0;
    }

    public Fotografia(int idfoto, String nombrefoto, int usuario_id) {
        this.idfoto = idfoto;
        this.nombrefoto = nombrefoto;
        this.usuario_id = usuario_id;
    }

    public int getIdfoto() {
        return idfoto;
    }

    public void setIdfoto(int idfoto) {
        this.idfoto = idfoto;
    }

    public String getNombrefoto() {
        return nombrefoto;
    }

    public void setNombrefoto(String nombrefoto) {
        this.nombrefoto = nombrefoto;
    }

    public int getUsuario_id() {
        return usuario_id;
    }

    public void setUsuario_id(int usuario_id) {
        this.usuario_id = usuario_id;
    }

    @Override
    public String toString() {
        return "Fotografia{" + "idfoto=" + idfoto + ", nombrefoto=" + nombrefoto + ", usuario_id=" + usuario_id + '}';
    }
    
}
