
package modelo;

import dao.CRUD;
import dao.Conexion;
import static dao.Conexion.abrirConexion;
import static dao.Conexion.cerrarConexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class AdminUsuarioDB extends Conexion implements CRUD {

    @Override
    public Object insertar(Object obj) {
        Connection conex = abrirConexion();
        Usuario objUsuario = (Usuario) obj;
        try {
            String sql = "INSERT INTO usuario(documento,nombres,apellidos,correinstitucional,direccion,telefono,fotousuario,rol_id) VALUES(?,?,?,?,?,?,?,?)";
            PreparedStatement preparedStatement = (PreparedStatement) conex.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
            preparedStatement.setString(1, objUsuario.getDocumento());
            preparedStatement.setString(2, objUsuario.getNombres());
            preparedStatement.setString(3, objUsuario.getApellidos());
            preparedStatement.setString(4, objUsuario.getCorreoinstitucional());
            preparedStatement.setString(5, objUsuario.getDireccion());
            preparedStatement.setString(6, objUsuario.getTelefono());
            preparedStatement.setString(7, objUsuario.getFotousuario());
            preparedStatement.setInt(8, objUsuario.getRol_id());
            preparedStatement.execute();

            ResultSet rs = preparedStatement.getGeneratedKeys();
            while (rs.next()) {
                objUsuario.setIdusuario(rs.getInt(1));
            }
            preparedStatement.close();
            System.out.println("La inserción de la persona fue exitosa");
        } catch (Exception e) {
            System.out.println("Error al insertar el usuario: "+e.getMessage());
        }
        cerrarConexion();
        return objUsuario;
    }

    @Override
    public boolean actualizar(Object obj) {
        Usuario objUsuario = (Usuario) obj;
        boolean flag = false;
        Connection conex = abrirConexion();
        try {
            String sql = "UPDATE usuario SET nombres=?, apellidos=?, correoinstitucional=?, direccion=?, telefono=?, fotousuario=?, rol_id=? WHERE documento=?";
            PreparedStatement preparedStatement = (PreparedStatement) conex.prepareStatement(sql);
            preparedStatement.setString(1, objUsuario.getNombres());
            preparedStatement.setString(2, objUsuario.getApellidos());
            preparedStatement.setString(3, objUsuario.getCorreoinstitucional());
            preparedStatement.setString(4, objUsuario.getDireccion());
            preparedStatement.setString(5, objUsuario.getTelefono());
            preparedStatement.setString(6, objUsuario.getFotousuario());
            preparedStatement.setInt(7, objUsuario.getRol_id());
            preparedStatement.setString(8, objUsuario.getDocumento());
            int totalFilasafectadas = preparedStatement.executeUpdate();
            if (totalFilasafectadas > 0) {
                flag = true;
            }
            preparedStatement.close();

        } catch (Exception e) {
            System.out.println("Error en la actualización del cliente: " + e.getMessage());
        }
        cerrarConexion();
        return flag;
    }

    @Override
    public boolean eliminar(Object obj) {
        Usuario objUsuario = (Usuario) obj;
        boolean flag = false;
        Connection conex = abrirConexion();
        try {
            String sql = "DELETE FROM usuario WHERE documento=?";
            PreparedStatement preparedStatement = (PreparedStatement) conex.prepareStatement(sql);
            preparedStatement.setString(1, objUsuario.getDocumento());
            int totalFilasafectadas = preparedStatement.executeUpdate();
            if(totalFilasafectadas>0){
                flag = true;
            }
            preparedStatement.close();
            
        } catch (Exception e) {
            System.out.println("Error al eliminar el rol: "+e.getMessage());
        }
        cerrarConexion();
        return flag;
    }

    @Override
    public List<Object> listarTodo() {
        List<Object> rowsQuery = new ArrayList<Object>();
        Connection conex = abrirConexion();
        Usuario objUsuario;
        try {
            String sql = "SELECT * FROM usuario ORDER BY id ASC";
            PreparedStatement preparedStatement = (PreparedStatement) conex.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                objUsuario = new Usuario();
                objUsuario.setIdusuario(resultSet.getInt("id"));
                objUsuario.setDocumento(resultSet.getString("documento"));
                objUsuario.setNombres(resultSet.getString("nombres"));
                objUsuario.setApellidos(resultSet.getString("apellidos"));
                objUsuario.setCorreoinstitucional(resultSet.getString("correoinstitucional"));
                objUsuario.setDireccion(resultSet.getString("direccion"));
                objUsuario.setTelefono(resultSet.getString("telefono"));
                objUsuario.setFotousuario(resultSet.getString("fotousuario"));
                objUsuario.setRol_id(resultSet.getInt("rol_id"));
                rowsQuery.add(objUsuario+"\n");
            }
            preparedStatement.close();
        } catch (SQLException ex) {
            System.out.println("Error en la adquisición de datos");
        }
        cerrarConexion();
        return rowsQuery;
    }

    @Override
    public Object listarUno(Object obj) {
        Connection conex = abrirConexion();
        Usuario objUsuario = (Usuario) obj;
        try {
            String sql = "SELECT * FROM rol WHERE documento = ?";
            PreparedStatement preparedStatement = (PreparedStatement) conex.prepareStatement(sql);
            preparedStatement.setString(1, objUsuario.getDocumento());
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                objUsuario.setIdusuario(resultSet.getInt("id"));
                objUsuario.setDocumento(resultSet.getString("documento"));
                objUsuario.setNombres(resultSet.getString("nombres"));
                objUsuario.setApellidos(resultSet.getString("apellidos"));
                objUsuario.setCorreoinstitucional(resultSet.getString("correoinstitucional"));
                objUsuario.setDireccion(resultSet.getString("direccion"));
                objUsuario.setTelefono(resultSet.getString("telefono"));
                objUsuario.setFotousuario(resultSet.getString("fotousuario"));
                objUsuario.setRol_id(resultSet.getInt("rol_id"));
            }
            preparedStatement.close();
        } catch (SQLException ex) {
            System.out.println("Error en la adquisición de datos: "+ex.getMessage());
        }
        cerrarConexion();
        return objUsuario;
    }
    
}
