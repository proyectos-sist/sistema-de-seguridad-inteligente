package modelo;

public class RelacionesDB {
    
}
