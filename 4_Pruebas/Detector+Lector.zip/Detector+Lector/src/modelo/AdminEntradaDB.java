
package modelo;


public class AdminEntradaDB {
    
}
